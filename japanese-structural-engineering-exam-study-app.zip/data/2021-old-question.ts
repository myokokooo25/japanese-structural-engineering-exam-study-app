
import { StudyCardData } from '../types';
import { chapter2021Part1Data } from './2021-old-question-part1';
import { chapter2021Part2Data } from './2021-old-question-part2';

export const chapter2021Data: StudyCardData[] = [
  ...chapter2021Part1Data,
  ...chapter2021Part2Data,
];

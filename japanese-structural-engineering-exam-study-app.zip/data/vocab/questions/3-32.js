export default [
  { jp: '鉄骨工事 (てっこつこうじ)', my: 'သံမဏိတည်ဆောက်ရေးလုပ်ငန်း', type: 'Noun' },
  { jp: '検査 (けんさ)', my: 'စစ်ဆေးမှု', type: 'Noun' },
  { jp: '抜取検査 (ぬきとりけんさ)', my: 'Sampling Inspection', type: 'Noun' },
  { jp: '許容 (きょよう)', my: 'ခွင့်ပြုသည်', type: 'Verb' },
  { jp: '材料 (ざいりょう)', my: 'ပစ္စည်း', type: 'Noun' },
  { jp: '受入検査 (うけいれけんさ)', my: 'Receiving Inspection', type: 'Noun' },
  { jp: '照合 (しょうごう)', my: 'တိုက်ဆိုင်စစ်ဆေးခြင်း', type: 'Noun' },
  { jp: '製品 (せいひん)', my: 'ထုတ်ကုန်', type: 'Noun' },
  { jp: '寸法検査 (すんぽうけんさ)', my: 'အတိုင်းအတာ စစ်ဆေးခြင်း', type: 'Noun' },
  { jp: '溶接部 (ようせつぶ)', my: 'ဂဟေဆက်နေရာ', type: 'Noun' },
  { jp: '外観検査 (がいかんけんさ)', my: 'အမြင်ပိုင်းဆိုင်ရာ စစ်ဆေးခြင်း', type: 'Noun' },
  { jp: '高力ボルト (こうりょくボルト)', my: 'High-strength bolt', type: 'Noun' },
  { jp: '締付け後 (しめつけご)', my: 'တပ်ဆင်ပြီးနောက်', type: 'Noun' },
  { jp: 'トルク検査 (トルクけんさ)', my: 'Torque စစ်ဆေးခြင်း', type: 'Noun' },
  { jp: '柱 (はしら)', my: 'တိုင်', type: 'Noun' },
  { jp: '建方精度検査 (たてかたせいどけんさ)', my: 'Erection accuracy inspection', type: 'Noun' }
];
export default [
  { jp: '施工 (せこう)', my: 'တည်ဆောက်ခြင်း', type: 'Noun' },
  { jp: '溶接作業 (ようせつさぎょう)', my: 'ဂဟေဆက်ခြင်းလုပ်ငန်း', type: 'Noun' },
  { jp: '記録 (きろく)', my: 'မှတ်တမ်း', type: 'Noun' },
  { jp: '次 (つぎ)', my: 'နောက်တစ်ခု', type: 'Noun' },
  { jp: '示す (しめす)', my: 'ပြသသည်', type: 'Verb' },
  { jp: '溶接施工条件 (ようせつせこうじょうけん)', my: 'ဂဟေဆက်ခြင်း အခြေအနေ', type: 'Noun' },
  { jp: '最も (もっとも)', my: 'အ...ဆုံး', type: 'Adverb' },
  { jp: '不適当 (ふてきとう)', my: 'မသင့်လျော်သော', type: 'Adjective' },
  { jp: '級鋼 (きゅうこう)', my: 'Grade Steel', type: 'Noun' }
];

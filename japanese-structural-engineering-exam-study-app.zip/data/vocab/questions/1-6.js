export default [
  { jp: '図 (ず)', my: 'ပုံ၊ ပုံကြမ်း', type: 'Noun' },
  { jp: '荷重 (かじゅう)', my: 'ဝန်၊ ဝန်အား', type: 'Noun' },
  { jp: '受ける (うける)', my: 'ခံယူသည်', type: 'Verb' },
  { jp: '梁 (はり)', my: 'Beam', type: 'Noun' },
  { jp: '各 (かく)', my: 'တစ်ခုချင်းစီ', type: 'Prefix' },
  { jp: '部材 (ぶざい)', my: 'အစိတ်အပိုင်း၊ Member', type: 'Noun' },
  { jp: '生じる (しょうじる)', my: 'ဖြစ်ပေါ်သည်', type: 'Verb' },
  { jp: '軸力 (じくりょく)', my: 'ဝင်ရိုးလိုက်အား၊ Axial Force', type: 'Noun' },
  { jp: '組合せ (くみあわせ)', my: 'ပေါင်းစပ်မှု', type: 'Noun' },
  { jp: '適当 (てきとう)', my: 'သင့်လျော်သော', type: 'Adjective' },
  { jp: '圧縮 (あっしゅく)', my: 'ဖိသိပ်အား၊ Compression', type: 'Noun' },
  { jp: '引張 (ひっぱり)', my: 'ဆွဲအား၊ Tension', type: 'Noun' }
];

export default [
  { jp: '図 (ず)', my: 'ပုံ၊ ပုံကြမ်း', type: 'Noun' },
  { jp: '荷重 (かじゅう)', my: 'ဝန်၊ ဝန်အား', type: 'Noun' },
  { jp: '受ける (うける)', my: 'ခံယူသည်', type: 'Verb' },
  { jp: '梁 (はり)', my: 'Beam', type: 'Noun' },
  { jp: '関する (かんする)', my: '...နှင့် ပတ်သက်သော', type: 'Verb' },
  { jp: '次 (つぎ)', my: 'နောက်တစ်ခု', type: 'Noun' },
  { jp: '記述 (きじゅつ)', my: 'ဖော်ပြချက်', type: 'Noun' },
  { jp: '最も (もっとも)', my: 'အ...ဆုံး', type: 'Adverb' },
  { jp: '不適当 (ふてきとう)', my: 'မသင့်လျော်သော', type: 'Adjective' },
  { jp: '支点 (してん)', my: 'အထောက်အမှတ်၊ Support', type: 'Noun' },
  { jp: '生じる (しょうじる)', my: 'ဖြစ်ပေါ်သည်', type: 'Verb' },
  { jp: '反力 (はんりょく)', my: 'တုံ့ပြန်အား၊ Reaction Force', type: 'Noun' },
  { jp: '等しい (ひとしい)', my: 'တူညီသော', type: 'Adjective' },
  { jp: '部材 (ぶざい)', my: 'အစိတ်အပိုင်း၊ Member', type: 'Noun' },
  { jp: '軸力 (じくりょく)', my: 'ဝင်ရိုးလိုက်အား၊ Axial Force', type: 'Noun' },
  { jp: '大きい (おおきい)', my: 'ကြီးသော', type: 'Adjective' }
];

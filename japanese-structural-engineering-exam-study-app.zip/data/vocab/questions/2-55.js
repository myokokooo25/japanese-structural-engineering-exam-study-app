export default [
  { jp: '溶融亜鉛めっき (ようゆうあえんめっき)', my: 'Hot-Dip Galvanizing', type: 'Noun' },
  { jp: '施す (ほどこす)', my: 'ပြုလုပ်သည်', type: 'Verb' },
  { jp: '部材 (ぶざい)', my: 'အစိတ်အပိုင်း', type: 'Noun' },
  { jp: '関する (かんする)', my: '...နှင့် ပတ်သက်သော', type: 'Verb' },
  { jp: '次 (つぎ)', my: 'နောက်တစ်ခု', type: 'Noun' },
  { jp: '記述 (きじゅつ)', my: 'ဖော်ပြချက်', type: 'Noun' },
  { jp: 'うち (うち)', my: '...အနက်', type: 'Grammar' },
  { jp: '不適当 (ふてきとう)', my: 'မသင့်လျော်သော', type: 'Adjective' },
  { jp: '組合せ (くみあわせ)', my: 'ပေါင်းစပ်မှု', type: 'Noun' }
];

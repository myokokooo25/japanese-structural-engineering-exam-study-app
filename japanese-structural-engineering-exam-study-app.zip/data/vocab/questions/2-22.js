export default [
  { jp: '次 (つぎ)', my: 'နောက်တစ်ခု', type: 'Noun' },
  { jp: '溶接継手 (ようせつつぎて)', my: 'ဂဟေဆက် အဆက်', type: 'Noun' },
  { jp: '実形 (じつけい)', my: 'ပုံစံ', type: 'Noun' },
  { jp: '対応 (たいおう)', my: 'သက်ဆိုင်သော', type: 'Noun' },
  { jp: '溶接記号 (ようせつきごう)', my: 'ဂဟေဆက် သင်္ကေတ', type: 'Noun' },
  { jp: '表記 (ひょうき)', my: 'ဖော်ပြချက်', type: 'Noun' },
  { jp: '第三角法 (だいさんかくほう)', my: 'Third Angle Projection', type: 'Noun' },
  { jp: '示す (しめす)', my: 'ပြသသည်', type: 'Verb' },
  { jp: '最も (もっとも)', my: 'အ...ဆုံး', type: 'Adverb' },
  { jp: '不適当 (ふてきとう)', my: 'မသင့်လျော်သော', type: 'Adjective' },
  { jp: '開先 (かいさき)', my: 'Bevel/Groove', type: 'Noun' },
  { jp: '突合せ継手 (つきあわせつぎて)', my: 'Butt Joint', type: 'Noun' },
  { jp: '裏当て金 (うらあてがね)', my: 'Backing Metal', type: 'Noun' },
  { jp: '付き (つき)', my: '...ပါသော', type: 'Suffix' },
  { jp: '形 (がた)', my: 'ပုံစံ', type: 'Suffix' },
  { jp: '連続 (れんぞく)', my: 'ဆက်တိုက်', type: 'Noun' },
  { jp: '隅肉 (すみにく)', my: 'Fillet', type: 'Noun' }
];

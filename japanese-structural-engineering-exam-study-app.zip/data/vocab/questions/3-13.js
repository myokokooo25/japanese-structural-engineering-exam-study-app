export default [
  { jp: '鉄骨 (てっこつ)', my: 'သံမဏိ', type: 'Noun' },
  { jp: '製作精度 (せいさくせいど)', my: 'ထုတ်လုပ်မှု တိကျမှု', type: 'Noun' },
  { jp: '関する (かんする)', my: '...နှင့် ပတ်သက်သော', type: 'Verb' },
  { jp: '許容差 (きょようさ)', my: 'Tolerance', type: 'Noun' },
  { jp: '規定 (きてい)', my: 'သတ်မှတ်သည်', type: 'Verb' },
  { jp: '柱 (はしら)', my: 'တိုင်', type: 'Noun' },
  { jp: '長さ (ながさ)', my: 'အရှည်', type: 'Noun' },
  { jp: '梁 (はり)', my: 'Beam', type: 'Noun' },
  { jp: 'そり', my: 'ကွေးညွှတ်မှု (sweep)', type: 'Noun' },
  { jp: '曲がり (まがり)', my: 'ကွေးညွှတ်မှု (camber/sweep)', type: 'Noun' },
  { jp: '高力ボルト (こうりょくボルト)', my: 'High-strength bolt', type: 'Noun' },
  { jp: '孔径 (こうけい)', my: 'အပေါက်အချင်း', type: 'Noun' },
  { jp: '溶接 (ようせつ)', my: 'ဂဟေဆက်ခြင်း', type: 'Noun' },
  { jp: '余盛 (よもり)', my: 'Reinforcement', type: 'Noun' },
  { jp: '色 (いろ)', my: 'အရောင်', type: 'Noun' }
];
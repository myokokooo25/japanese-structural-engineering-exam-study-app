export default [
  { jp: '非破壊検査 (ひはかいけんさ)', my: 'NDT', type: 'Noun' },
  { jp: '関する (かんする)', my: '...နှင့် ပတ်သက်သော', type: 'Verb' },
  { jp: '次 (つぎ)', my: 'နောက်တစ်ခု', type: 'Noun' },
  { jp: '記述 (きじゅつ)', my: 'ဖော်ပြချက်', type: 'Noun' },
  { jp: '表面欠陥 (ひょうめんけっかん)', my: 'မျက်နှာပြင် ချို့ယွင်းချက်', type: 'Noun' },
  { jp: '検出 (けんしゅつ)', my: 'ရှာဖွေသည်', type: 'Verb' },
  { jp: '最も (もっとも)', my: 'အ...ဆုံး', type: 'Adverb' },
  { jp: '適していない (てきしていない)', my: 'မသင့်လျော်သော', type: 'Adjective' },
  { jp: '磁粉探傷検査 (じふんたんしょうけんさ)', my: 'Magnetic Particle Testing (MT)', type: 'Noun' },
  { jp: '浸透探傷検査 (しんとうたんしょうけんさ)', my: 'Penetrant Testing (PT)', type: 'Noun' },
  { jp: '目視検査 (もくしけんさ)', my: 'Visual Testing (VT)', type: 'Noun' },
  { jp: '放射線透過検査 (ほうしゃせんとうかけんさ)', my: 'Radiographic Testing (RT)', type: 'Noun' },
  { jp: '渦電流探傷検査 (うずでんりゅうたんしょうけんさ)', my: 'Eddy Current Testing (ET)', type: 'Noun' }
];